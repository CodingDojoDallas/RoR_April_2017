class Mammal
	def initialize health = 150, food = 30
		@health = health
		@food = food
	end

	def display_health
		puts "health is #{@health}"
		self
	end	
	def display_food
		puts "food is #{@food} lbs"
	end	
end		

Dolphin = Mammal.new
