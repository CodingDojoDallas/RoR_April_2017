class Ninja < ApplicationRecord
  belongs_to :dojo
end
